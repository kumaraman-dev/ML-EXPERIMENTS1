import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from data import load_data

def visualize_iris():
    """
    Generates scatter plots for all unique feature pairs in the Iris dataset.
    Each point is colored based on the flower species.
    """

    # Load the Iris data
    X, y = load_data()

    # Convert NumPy arrays back to DataFrame for easy plotting
    feature_names = ['sepal length', 'sepal width', 'petal length', 'petal width']
    df = pd.DataFrame(X, columns=feature_names)
    df['species'] = y

    # List of unique species
    species = df['species'].unique()
    colors = ['red', 'green', 'blue']

    # Generate scatter plots for all unique feature pairs
    num_features = len(feature_names)
    plot_num = 1
    plt.figure(figsize=(12, 10))

    for i in range(num_features):
        for j in range(i + 1, num_features):
            plt.subplot(3, 2, plot_num)
            for sp, color in zip(species, colors):
                subset = df[df['species'] == sp]
                plt.scatter(subset[feature_names[i]], subset[feature_names[j]],
                            label=sp, color=color, alpha=0.7)
            plt.xlabel(feature_names[i])
            plt.ylabel(feature_names[j])
            plt.title(f"{feature_names[i]} vs {feature_names[j]}")
            plt.legend()
            plot_num += 1

    plt.tight_layout()
    plt.show()


# ✅ Run directly if executed as a standalone script
if __name__ == "__main__":
    visualize_iris()
