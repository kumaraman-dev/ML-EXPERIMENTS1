import numpy as np

def train_test_split(X, y, test_size=0.2, random_state=None):
    """
    Splits the dataset into training and testing sets.

    Parameters:
    -----------
    X : numpy.ndarray
        Feature matrix.
    y : numpy.ndarray
        Target vector.
    test_size : float
        Proportion of the dataset to include in the test split (default: 0.2).
    random_state : int, optional
        Random seed for reproducibility.

    Returns:
    --------
    X_train, X_test, y_train, y_test : numpy.ndarrays
        Split data arrays.
    """
    # 1️⃣ Set the random seed (for reproducibility)
    if random_state is not None:
        np.random.seed(random_state)

    # 2️⃣ Generate shuffled indices
    num_samples = X.shape[0]
    indices = np.arange(num_samples)
    np.random.shuffle(indices)

    # 3️⃣ Determine test size
    test_size_count = int(num_samples * test_size)

    # 4️⃣ Split indices into train and test
    test_indices = indices[:test_size_count]
    train_indices = indices[test_size_count:]

    # 5️⃣ Slice the arrays
    X_train, X_test = X[train_indices], X[test_indices]
    y_train, y_test = y[train_indices], y[test_indices]

    return X_train, X_test, y_train, y_test


# ✅ Optional test block
if __name__ == "__main__":
    # Just a simple check with dummy data
    X = np.arange(20).reshape(10, 2)
    y = np.array(["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"])

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    print("X_train shape:", X_train.shape)
    print("X_test shape:", X_test.shape)
    print("y_train:", y_train)
    print("y_test:", y_test)
