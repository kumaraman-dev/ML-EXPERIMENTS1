import pandas as pd
import numpy as np
from ucimlrepo import fetch_ucirepo

def load_data():
    """
    Loads and preprocesses the Iris dataset from UCI repository.
    Returns:
        X (numpy.ndarray): Feature matrix
        y (numpy.ndarray): Target vector
    """
    # Step 1: Fetch the Iris dataset
    iris = fetch_ucirepo(id=53)

    # Step 2: Extract features and target
    X = iris.data.features
    y = iris.data.targets

    # Step 3: Clean target labels (remove 'Iris-' prefix)
    y = y.replace({
        'Iris-setosa': 'setosa',
        'Iris-versicolor': 'versicolor',
        'Iris-virginica': 'virginica'
    })

    # Step 4: Convert DataFrames to NumPy arrays
    X = X.to_numpy()
    y = y.to_numpy().ravel()

    return X, y

# Optional test code — only runs if you execute data.py directly
if __name__ == "__main__":
    X, y = load_data()
    print("Feature shape:", X.shape)
    print("Target shape:", y.shape)
    print("Sample features:\n", X[:5])
    print("Sample targets:\n", y[:5])
