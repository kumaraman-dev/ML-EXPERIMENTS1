import numpy as np
from collections import Counter

# ---------------------------------------------
# 1️⃣ Euclidean Distance Function
# ---------------------------------------------
def euclidean_distance(x1, x2):
    """
    Compute the Euclidean distance between two vectors.
    Formula: sqrt(sum((x1 - x2)^2))
    """
    return np.sqrt(np.sum((x1 - x2) ** 2))


# ---------------------------------------------
# 2️⃣ KNN Classifier Implementation
# ---------------------------------------------
class KNNClassifier:
    def __init__(self, k=3):
        """
        Initialize the KNN classifier with the number of neighbors (k).
        """
        self.k = k

    def fit(self, X_train, y_train):
        """
        Store training data.
        """
        self.X_train = X_train
        self.y_train = y_train

    def predict(self, X_test):
        """
        Predict labels for all samples in X_test.
        """
        predictions = [self._predict(x) for x in X_test]
        return np.array(predictions)

    def _predict(self, x):
        """
        Predict the label for a single sample x.
        Steps:
          1. Compute distances to all training samples
          2. Find the k nearest neighbors
          3. Perform majority voting among neighbors
        """
        # Compute distances to every training point
        distances = [euclidean_distance(x, x_train) for x_train in self.X_train]

        # Get indices of k smallest distances
        k_indices = np.argsort(distances)[:self.k]

        # Extract the labels of these k neighbors
        k_nearest_labels = [self.y_train[i] for i in k_indices]

        # Majority vote
        most_common = Counter(k_nearest_labels).most_common(1)
        return most_common[0][0]


# ---------------------------------------------
# ✅ Optional Test Block
# ---------------------------------------------
if __name__ == "__main__":
    # Simple test with dummy data
    X_train = np.array([
        [1, 2],
        [2, 3],
        [3, 4],
        [6, 7],
        [7, 8]
    ])
    y_train = np.array(['A', 'A', 'A', 'B', 'B'])

    X_test = np.array([
        [2, 2],
        [6, 6]
    ])

    model = KNNClassifier(k=3)
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    print("Predictions:", predictions)
