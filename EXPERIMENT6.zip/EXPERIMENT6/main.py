import numpy as np
import matplotlib.pyplot as plt
from data import load_data
from utils import train_test_split
from knn_classifier import KNNClassifier


def accuracy_score(y_true, y_pred):
    """Calculate accuracy as (correct / total) * 100."""
    correct = np.sum(y_true == y_pred)
    return correct / len(y_true) * 100


def run_knn_experiment():
    # 1️⃣ Load the data
    X, y = load_data()

    # 2️⃣ Split into train and test sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # 3️⃣ Define list of k values for tuning
    k_values = [1, 3, 5, 7, 9, 11, 15]
    accuracies = []

    # 4️⃣ Train and evaluate model for each k
    for k in k_values:
        model = KNNClassifier(k=k)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        acc = accuracy_score(y_test, predictions)
        accuracies.append(acc)
        print(f"k = {k}, Accuracy = {acc:.2f}%")

    # 5️⃣ Plot accuracy vs k
    plt.figure(figsize=(8, 5))
    plt.plot(k_values, accuracies, marker='o', linestyle='-', color='b')
    plt.title("KNN Accuracy vs K-value")
    plt.xlabel("Number of Neighbors (k)")
    plt.ylabel("Accuracy (%)")
    plt.grid(True)
    plt.show()

    # 6️⃣ Find best k
    best_k = k_values[np.argmax(accuracies)]
    print(f"\n✅ Best k value: {best_k} with Accuracy = {max(accuracies):.2f}%")

    return best_k


if __name__ == "__main__":
    best_k = run_knn_experiment()
